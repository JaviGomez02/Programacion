
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona p1=new Persona();
		Persona p2=new Persona("Antonio Miguel",34,'H');
		Persona p3=new Persona("Jose luis",23,"3422213",'M',78,1.78);
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println(p3.toString());
	}

}
